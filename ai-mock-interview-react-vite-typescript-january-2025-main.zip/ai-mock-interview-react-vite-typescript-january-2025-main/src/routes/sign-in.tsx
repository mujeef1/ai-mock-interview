import { SignIn } from "@clerk/clerk-react";

export const SignInPage = () => {
  return <SignIn path="/signin" />;
};
